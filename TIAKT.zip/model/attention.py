import torch
import math
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import xavier_uniform_, constant_

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class MultiHeadAttention(nn.Module):
    def __init__(self, d_model, d_feature, n_heads, dropout, kq_same, bias=True):
        super().__init__()
        self.d_model = d_model
        self.d_k = d_feature
        self.h = n_heads
        self.kq_same = kq_same
        self.v_linear = nn.Linear(d_model, d_model, bias=bias)
        self.k_linear = nn.Linear(d_model, d_model, bias=bias)
        self.q_linear = nn.Linear(d_model, d_model, bias=bias) if not kq_same else self.k_linear
        self.dropout = nn.Dropout(dropout)
        self.out_proj = nn.Linear(d_model, d_model, bias=bias)
        self.gammas = nn.Parameter(torch.zeros(n_heads, 1, 1))
        torch.nn.init.xavier_uniform_(self.gammas)
        self._reset_parameters()

    def _reset_parameters(self):
        xavier_uniform_(self.k_linear.weight)
        xavier_uniform_(self.v_linear.weight)
        if not self.kq_same:
            xavier_uniform_(self.q_linear.weight)
        constant_(self.k_linear.bias, 0.)
        constant_(self.v_linear.bias, 0.)
        if not self.kq_same:
            constant_(self.q_linear.bias, 0.)
        constant_(self.out_proj.bias, 0.)

    def forward(self, q, k, v, mask, zero_pad):
        bs = q.size(0)
        k = self.k_linear(k).view(bs, -1, self.h, self.d_k).transpose(1, 2)
        q = (self.q_linear(q) if not self.kq_same else self.k_linear(q)).view(bs, -1, self.h, self.d_k).transpose(1, 2)
        v = self.v_linear(v).view(bs, -1, self.h, self.d_k).transpose(1, 2)

        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_k)
        seqlen = scores.size(2)
        x1 = torch.arange(seqlen).expand(seqlen, -1).to(device)
        x2 = x1.transpose(0, 1).contiguous()

        with torch.no_grad():
            scores_ = scores.masked_fill(mask == 0, -1e32)
            scores_ = F.softmax(scores_, dim=-1) * mask.float().to(device)
            distcum_scores = torch.cumsum(scores_, dim=-1)
            disttotal_scores = torch.sum(scores_, dim=-1, keepdim=True)
            position_effect = torch.abs(x1 - x2)[None, None, :, :].float().to(device)
            dist_scores = torch.clamp((disttotal_scores - distcum_scores) * position_effect, min=0.).sqrt().detach()

        gamma = -1. * nn.Softplus()(self.gammas).unsqueeze(0)
        total_effect = torch.clamp((dist_scores * gamma).exp(), min=1e-5, max=1e5)
        scores = scores * total_effect
        scores.masked_fill_(mask == 0, -1e32)
        scores = F.softmax(scores, dim=-1)
        if zero_pad:
            pad_zero = torch.zeros(bs, self.h, 1, seqlen).to(device)
            scores = torch.cat([pad_zero, scores[:, :, 1:, :]], dim=2)
        scores = self.dropout(scores)
        output = torch.matmul(scores, v)
        concat = output.transpose(1, 2).contiguous().view(bs, -1, self.d_model)
        return self.out_proj(concat)
