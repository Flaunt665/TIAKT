import torch
from torch import nn

class NeuralMemory(nn.Module):
    def __init__(self, mem_dim, mem_slots):
        super().__init__()
        self.mem_slots = mem_slots
        self.mem_dim = mem_dim
        self.memory = nn.Parameter(torch.randn(mem_slots, mem_dim))
        nn.init.xavier_uniform_(self.memory)

    def forward(self, x):
        batch = x.size(0)
        return self.memory.unsqueeze(0).repeat(batch, 1, 1)
