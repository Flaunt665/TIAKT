from enum import IntEnum

class Dim(IntEnum):
    batch = 0
    seq = 1
    feature = 2
